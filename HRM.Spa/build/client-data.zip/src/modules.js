// import chart from "app-player-chart";
export default {
    // static import (included in main.*.js)    
    // chart: chart 
    // dynamic import (included in chun.*.jsk)
    // chart: () => "app-player-chart" 
};